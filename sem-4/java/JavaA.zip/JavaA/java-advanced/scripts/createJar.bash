#!/bin/bash


my_module="info.kgeorgiy.ja.rassadnikov.implementor"
gk_module="info.kgeorgiy.java.advanced.implementor"

path="../../java-advanced-2023/modules/$gk_module/info/kgeorgiy/java/advanced/implementor"

javac  -cp ../java-solutions -d my_module \
 $my_module $path/Impler.java $path/JarImpler.java $path/ImplerException.java

jar -cvfm Impler.jar MANIFEST.MF ../java-solutions/info.kgeorgiy.ja.rassadnikov.implementor.Implementor.class