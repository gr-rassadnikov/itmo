#!/bin/bash


my_module="info.kgeorgiy.ja.rassadnikov.implementor"
gk_module="info.kgeorgiy.java.advanced.implementor"

path="../../java-advanced-2023/modules/$gk_module/info/kgeorgiy/java/advanced/implementor"

javac   ../java-solutions -d ../ \
 $my_module $path/Impler.java $path/JarImpler.java $path/ImplerException.java

javac -p $source/artifacts:$source/lib --module-source-path . -d . $packagePath/Implementor.java
jar -cvfm Impler.jar MANIFEST.MF ../java-solutions/info.kgeorgiy.ja.rassadnikov.implementor.Implementor