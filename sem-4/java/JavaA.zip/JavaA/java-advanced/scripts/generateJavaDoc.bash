#!/bin/bashja

my_module="info.kgeorgiy.ja.rassadnikov.implementor"
gk_module="info.kgeorgiy.java.advanced.implementor"

path="../../java-advanced-2023/modules/$gk_module/info/kgeorgiy/java/advanced/implementor"

javadoc  -quiet -author -version -private -cp ../java-solutions -d ../javadoc \
 $my_module $path/Impler.java $path/JarImpler.java $path/ImplerException.java