package info.kgeorgiy.ja.rassadnikov.arrayset;

import java.util.*;

public class ArraySet<T> extends AbstractSet<T> implements SortedSet<T> {

    private final List<T> array;
    private final Comparator<? super T> comparator;

    public ArraySet() {
        this(Collections.emptyList(), null);
    }

    public ArraySet(Collection<? extends T> collection) {
        this(new ArrayList<>(new TreeSet<>(collection)), null);
    }

    public ArraySet(Comparator<? super T> comparator) {
        this(Collections.emptyList(), comparator);
    }

    public ArraySet(Collection<? extends T> collection, Comparator<? super T> comparator) {
        TreeSet<T> treeSet = new TreeSet<>(comparator);
        treeSet.addAll(collection);
        this.array = new ArrayList<>(treeSet);
        this.comparator = comparator;
    }

    @Override
    public Comparator<? super T> comparator() {
        return comparator;
    }

    @Override
    public SortedSet<T> subSet(T fromElement, T toElement) {
        return sub(fromElement, toElement);
    }

    @Override
    public SortedSet<T> headSet(T toElement) {
        return sub(null, toElement);
    }

    @Override
    public SortedSet<T> tailSet(T fromElement) {
        return sub(fromElement, null);
    }

    @Override
    public T first() {
        checkNotEmpty();
        return array.get(0);
    }

    @Override
    public T last() {
        checkNotEmpty();
        return array.get(array.size() - 1);
    }

    @Override
    public int size() {
        return array.size();
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean contains(Object o) {
        return Collections.binarySearch(array, Objects.requireNonNull((T) o), comparator) >= 0;
    }

    @Override
    public Iterator<T> iterator() {
        return array.iterator();
    }

    private int index(T value) {
        final int index = Collections.binarySearch(array, value, comparator);
        return index < 0 ? -index - 1 : index;
    }

    private void checkNotEmpty() {
        if (isEmpty()) {
            throw new NoSuchElementException("ArraySet is empty");
        }
    }

    private ArraySet<T> sub(T fromElement, T toElement) {
        if (fromElement != null && toElement != null) {
            if (comparator != null && comparator.compare(fromElement, toElement) > 0) {
                throw new IllegalArgumentException("expected fromKey > toKey");
            }
        }

        final int fromIndex = fromElement == null ? 0 : index(fromElement);
        final int toIndex = toElement == null ? size() : index(toElement);
        if (fromIndex > toIndex || fromIndex < 0 || toIndex > size()) {
            return new ArraySet<>(comparator);
        }

        return new ArraySet<>(array.subList(fromIndex, toIndex), comparator);
    }

    private ArraySet(List<T> list, Comparator<? super T> comparator) {
        this.array = list;
        this.comparator = comparator;
    }
}
