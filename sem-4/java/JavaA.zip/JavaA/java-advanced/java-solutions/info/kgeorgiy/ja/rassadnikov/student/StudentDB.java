package info.kgeorgiy.ja.rassadnikov.student;

import info.kgeorgiy.java.advanced.student.GroupName;
import info.kgeorgiy.java.advanced.student.Student;
import info.kgeorgiy.java.advanced.student.StudentQuery;

import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StudentDB implements StudentQuery {

    private static final Comparator<Student> ORDER_BY_NAME_COMPARATOR = Comparator
            .comparing(Student::getLastName)
            .thenComparing(Student::getFirstName)
            .reversed()
            .thenComparing(Student::getId);

    @Override
    public List<String> getFirstNames(List<Student> students) {
        return getListOfStudentsField(students, Student::getFirstName);
    }

    @Override
    public List<String> getLastNames(List<Student> students) {
        return getListOfStudentsField(students, Student::getLastName);
    }

    @Override
    public List<GroupName> getGroups(List<Student> students) {
        return getListOfStudentsField(students, Student::getGroup);
    }

    @Override
    public List<String> getFullNames(List<Student> students) {
        return getListOfStudentsField(students, student ->
                student.getFirstName() + " " + student.getLastName());
    }

    @Override
    public Set<String> getDistinctFirstNames(List<Student> students) {
        return getCollectionOfStudentsField(students, Student::getFirstName, Collectors.toUnmodifiableSet());
    }

    @Override
    public String getMaxStudentFirstName(List<Student> students) {
        return students.stream()
                .max(Student::compareTo)
                .map(Student::getFirstName)
                .orElse("");
    }

    @Override
    public List<Student> sortStudentsById(Collection<Student> students) {
        return sortStudentByFunction(students, Student::compareTo);
    }

    @Override
    public List<Student> sortStudentsByName(Collection<Student> students) {
        return sortStudentByFunction(students, ORDER_BY_NAME_COMPARATOR);
    }

    @Override
    public List<Student> findStudentsByFirstName(Collection<Student> students, String name) {
        return findStudentsByField(students, name, Student::getFirstName);
    }

    @Override
    public List<Student> findStudentsByLastName(Collection<Student> students, String name) {
        return findStudentsByField(students, name, Student::getLastName);
    }

    @Override
    public List<Student> findStudentsByGroup(Collection<Student> students, GroupName group) {
        return findStudentsByField(students, group, Student::getGroup);
    }

    @Override
    public Map<String, String> findStudentNamesByGroup(Collection<Student> students, GroupName group) {
        return findStudentsByGroup(students, group).stream()
                .collect(Collectors.toUnmodifiableMap(
                        Student::getLastName,
                        Student::getFirstName,
                        BinaryOperator.minBy(String::compareTo)));
    }


    private <T, A, R extends Collection<T>> R getCollectionOfStudentsField(Collection<Student> students,
                                                                           Function<Student, T> field,
                                                                           Collector<T, A, R> collector) {
        return students.stream()
                .map(field)
                .collect(collector);
    }

    private <T> List<T> getListOfStudentsField(Collection<Student> students, Function<Student, T> field) {
        return getCollectionOfStudentsField(students, field, Collectors.toUnmodifiableList());
    }

    private List<Student> sortStudentByFunction(Collection<Student> students, Comparator<Student> comparator) {
        return students.stream()
                .sorted(comparator)
                .toList();
    }

    private <T> List<Student> findStudentsByField(Collection<Student> students,
                                                  T compared,
                                                  Function<Student, T> field) {
        return students.stream()
                .filter(student -> compared.equals(field.apply(student)))
                .sorted(ORDER_BY_NAME_COMPARATOR)
                .toList();
    }

}
