package info.kgeorgiy.ja.rassadnikov.walk;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

public class Walk {
    private final static String HASH_NULL_SHA256 = "0".repeat(64);

    public static void main(String[] args) {
        if (args == null || args.length != 2 || args[0] == null || args[1] == null) {
            System.err.println("ERROR: invalid format arguments, expected: <input file> <output file>. ");
            return;
        }
        walk(args[0], args[1]);
    }

    private static void walk(String inputFileName, String outputFleName) {
        final Path inputFilePath, outputFilePath;
        try {
            inputFilePath = Paths.get(inputFileName);
        } catch (InvalidPathException e) {
            System.err.println("ERROR: Invalid path for input file. " + e.getMessage());
            return;
        }
        try {
            outputFilePath = Paths.get(outputFleName);
        } catch (InvalidPathException e) {
            System.err.println("ERROR: Invalid path for output file. " + e.getMessage());
            return;
        }
        try {
            final Path parentOutputFilePath = outputFilePath.getParent();
            if (parentOutputFilePath != null) {
                Files.createDirectories(parentOutputFilePath);
            }
        } catch (IOException e) {
            System.err.println("ERROR: can't create output file from parent output file. " + e.getMessage());
        }

        try (BufferedReader reader = Files.newBufferedReader(inputFilePath)) {
            try (BufferedWriter writer = Files.newBufferedWriter(outputFilePath)) {
                String fileName;
                MessageDigest digest;
                try {
                    digest = MessageDigest.getInstance("SHA-256");
                } catch (NoSuchAlgorithmException e) {
                    System.err.println("ERROR: Digest not found SHA-256 in MessageDigest algorithms");
                    return;
                }
                while ((fileName = reader.readLine()) != null) {
                    try {
                        writer.write(String.format("%s %s", hashOfFile(Paths.get(fileName), digest), fileName));
                        writer.newLine();
                    } catch (InvalidPathException e) {
                        writer.write(String.format("%s %s", HASH_NULL_SHA256, fileName));
                        writer.newLine();
                    }
                }
            } catch (FileNotFoundException e) {
                System.err.println("ERROR: not found output file. " + e.getMessage());
            } catch (SecurityException e) {
                System.err.println("ERROR: Security Exception with output file. " + e.getMessage());
            } catch (IOException e) {
                System.err.println("ERROR: Exception with output file. " + e.getMessage());
            }
        } catch (FileNotFoundException e) {
            System.err.println("ERROR: not found input file. " + e.getMessage());
        } catch (SecurityException e) {
            System.err.println("ERROR: Security Exception with input file. " + e.getMessage());
        } catch (IOException e) {
            System.err.println("ERROR: Exception with input file. " + e.getMessage());
        }
    }

    private static String hashOfFile(Path pathFile, MessageDigest digest) {
        try (InputStream inputStream = Files.newInputStream(pathFile)) {
            byte[] bytes = new byte[1024];
            int bytesCount;
            while ((bytesCount = inputStream.read(bytes)) != -1) {
                digest.update(bytes, 0, bytesCount);
            }
        } catch (IOException e) {
            return HASH_NULL_SHA256;
        }
        return HexFormat.of().formatHex(digest.digest());
    }
}
