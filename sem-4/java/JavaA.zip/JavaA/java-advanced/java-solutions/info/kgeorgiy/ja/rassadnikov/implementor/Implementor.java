package info.kgeorgiy.ja.rassadnikov.implementor;

import info.kgeorgiy.java.advanced.implementor.Impler;
import info.kgeorgiy.java.advanced.implementor.ImplerException;
import info.kgeorgiy.java.advanced.implementor.JarImpler;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;
import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;
import java.util.jar.JarOutputStream;
import java.util.jar.Manifest;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;

/**
 * Implementation for {@link Impler} and {@link JarImpler}.
 *
 * @author Rassadnikov Grigorii
 * @version 1.2.0
 **/
public class Implementor implements Impler, JarImpler {

    /**
     * Default constructor.
     */
    public Implementor() {

    }

    /**
     * Generate implementation of {@code clazz} in the transmitted path. {@code clazz} must be interface.
     * Implementation will be generated with suffix "Impl".
     *
     * @param clazz type token to create implementation for.
     * @param root  root directory.
     * @throws ImplerException when clazz doesn't confirm
     **/
    @Override
    public void implement(Class<?> clazz, Path root) throws ImplerException {
        checkIsInterface(clazz);
        checkIsNotPrivate(clazz);

        Path path = root.resolve(clazz.getPackage().getName().replace('.', '/'))
                .resolve(clazz.getSimpleName() + "Impl.java");

        checkIOAndCreateOFile(path);

        try (BufferedWriter bufferedWriter = Files.newBufferedWriter(path)) {
            bufferedWriter.write(generateClass(clazz));
        } catch (IOException e) {
            throw new ImplerException("ERROR: can't create file at path. " + e.getMessage());
        }
    }

    /**
     * Check that {@code clazz} is interface.
     *
     * @param clazz for checking.
     * @throws ImplerException if class isn't interface.
     */
    private void checkIsInterface(Class<?> clazz) throws ImplerException {
        if (!clazz.isInterface()) {
            throw new ImplerException("ERROR: expected interface. ");
        }
    }

    /**
     * Check that {@code clazz} isn't private.
     *
     * @param clazz for checking.
     * @throws ImplerException if class is private
     */
    private void checkIsNotPrivate(Class<?> clazz) throws ImplerException {
        if (Modifier.isPrivate(clazz.getModifiers())) {
            throw new ImplerException("ERROR: expected not private interface. ");
        }
    }

    /**
     * Create parent directory for out file at {@code path}.
     *
     * @param path out file.
     * @throws ImplerException if catch IOException.
     */
    private void checkIOAndCreateOFile(Path path) throws ImplerException {
        try {
            final Path parentOutputFilePath = path.getParent();
            if (parentOutputFilePath != null) {
                Files.createDirectories(parentOutputFilePath);
            }
        } catch (IOException e) {
            throw new ImplerException("ERROR: can't create class from parent directory class file. " + e.getMessage());
        }
    }

    /**
     * Generate {@link String} of java code-class for {@code clazz}.
     *
     * @param clazz from generate.
     * @return {@link String} of java code-class.
     */
    private String generateClass(Class<?> clazz) {
        return generatePackage(clazz) + ";" + System.lineSeparator()
                + System.lineSeparator()
                + generateDeclaration(clazz) + " {" + System.lineSeparator()
                + System.lineSeparator()
                + generateMethods(clazz)
                + "}" + System.lineSeparator();
    }

    /**
     * Generate {@link String} of package for {@code clazz}.
     *
     * @param clazz from generate.
     * @return {@link String} of package.
     */
    private String generatePackage(Class<?> clazz) {
        return clazz.getPackage().toString();
    }

    /**
     * Generate {@link String} of declaration for {@code clazz}.
     *
     * @param clazz from generate.
     * @return {@link String} of declaration.
     */

    private String generateDeclaration(Class<?> clazz) {
        return "public class " + clazz.getSimpleName() + "Impl implements " + clazz.getCanonicalName();
    }

    /**
     * Generate {@link String} of non-abstract methods for {@code clazz}.
     *
     * @param clazz from generate.
     * @return {@link String} of methods.
     */

    private String generateMethods(Class<?> clazz) {
        StringBuilder strB = new StringBuilder();
        for (Method method : clazz.getMethods()) {
            if (!Modifier.isAbstract(method.getModifiers())) {
                continue;
            }
            strB.append(generateMethod(method));
            strB.append(System.lineSeparator());
        }
        return strB.toString();
    }

    /**
     * Generate {@link String} of method for {@code method}.
     *
     * @param method from generate.
     * @return {@link String} of method.
     */
    private String generateMethod(Method method) {
        return "\t@Override" + System.lineSeparator()
                + "\tpublic " + method.getReturnType().getCanonicalName() + " " + method.getName() +
                "(" + generateParameters(method) + ") {" + System.lineSeparator()
                + "\t\treturn" + generateReturnValue(method.getReturnType()) + ";" + System.lineSeparator()
                + "\t}" + System.lineSeparator();
    }

    /**
     * Generate {@link String} of parameters for {@code method}.
     *
     * @param method from generate.
     * @return {@link String} of parameters.
     */
    private String generateParameters(Method method) {
        StringBuilder strB = new StringBuilder();
        boolean needComma = false;
        for (Parameter parameter : method.getParameters()) {
            if (needComma) {
                strB.append(", ");
            } else {
                needComma = true;
            }
            strB.append(parameter.getType().getCanonicalName());
            strB.append(" ").append(parameter.getName());
        }
        return strB.toString();
    }

    /**
     * Generate {@link String} of return value for {@code returnType}.
     *
     * @param returnType to generate.
     * @return {@link String} of methods.
     */
    private String generateReturnValue(Class<?> returnType) {
        if (returnType.equals(void.class)) {
            return "";
        } else if (returnType.equals(boolean.class)) {
            return " false";
        } else if (returnType.isPrimitive()) {
            return " 0";
        } else {
            return " null";
        }
    }

    /**
     * Main function for run Implementor with args.
     * Depending on the number of arguments and compilation keys, a different process occurs.
     * <ul>
     *     <li>Run {@link #implement(Class, Path)}. Expect: "name of interface".</li>
     *     <li>Run {@link #implementJar(Class, Path)}. Expect: -jar "name of interface" "jar file".</li>
     * </ul>
     *
     * @param args - argument for running main/from console.
     * @throws ImplerException if {@link #implement(Class, Path)} or {@link #implementJar(Class, Path)}
     *                         will throw with {@link ImplerException}.
     */
    public static void main(String[] args) throws ImplerException {
        System.out.println("Start main");
        if (args == null || (args.length != 1 && args.length != 3)) {
            System.err.println("ERROR: invalid format arguments, expected: <name of interface> " +
                    "/expected: -jar <name of interface> <jar file>");
            return;
        }

        Implementor implementor = new Implementor();
        try {
            if (args.length == 1) {
                implementor.implement(Class.forName(args[0]), Paths.get(""));
            } else if (args[0].equals("-jar")) {
                implementor.implementJar(Class.forName(args[1]), Paths.get(args[2]));
            } else {
                System.err.println("ERROR: use correct flags, expected: -jar <name of interface> <jar file>");
            }
        } catch (ClassNotFoundException e) {
            System.err.println("ERROR: can't found interface. " + e.getMessage());
        } catch (InvalidPathException e) {
            System.err.println("ERROR: invalid path" + e.getMessage());
        }
    }

    /**
     * Generate {@code jarfile} for implement of {@code clazz}.
     * Create jar file consisting of implement of {@code clazz}, MANIFEST.MF at {@code jarFile} path.
     *
     * @param clazz   type token to create implementation for.
     * @param jarFile target <var>.jar</var> file.
     * @throws ImplerException if can't create temp directory/ exception at implement.
     */
    @Override
    public void implementJar(Class<?> clazz, Path jarFile) throws ImplerException {
        checkIOAndCreateOFile(jarFile);
        Path dir;
        try {
            if (jarFile.getParent() != null) {
                dir = Files.createTempDirectory(jarFile.getParent(), "temp");
            } else {
                dir = Paths.get("");
            }
        } catch (IOException e) {
            throw new ImplerException("ERROR: can't create temp directory. " + e.getMessage());
        }
        try {
            implement(clazz, dir);
            compile(dir, clazz);

            final Manifest manifest = new Manifest();
            final Attributes attributes = manifest.getMainAttributes();
            attributes.put(Attributes.Name.MANIFEST_VERSION, "1.0");
            attributes.put(Attributes.Name.IMPLEMENTATION_VENDOR, "Rassadnikov Grigorii");

            try (JarOutputStream jarOutputStream = new JarOutputStream(Files.newOutputStream(jarFile), manifest)) {
                final String className = getImplName(clazz) + ".class";
                final Path source = dir.resolve(className);
                jarOutputStream.putNextEntry(new ZipEntry(className));
                Files.copy(source, jarOutputStream);
                jarOutputStream.closeEntry();
            } catch (IOException e) {
                throw new ImplerException("ERROR: can't create JarOutputStream. " + e.getMessage());
            }
        } finally {
            try (Stream<Path> stream = Files.walk(dir)) {
                stream.map(Path::toFile).forEach(File::delete);
            } catch (IOException e) {
                System.err.println("WARNING: can't delete temp directory. " + e.getMessage());
            }
        }
    }

    /**
     * Compile {@code classes}. Using system java compiler.
     *
     * @param root    path for generate correct class-path.
     * @param classes for compile.
     * @throws ImplerException if can't find system java compiler or exit code from run compiler isn't 0.
     */
    private void compile(Path root, Class<?>... classes) throws ImplerException {
        List<String> files = new ArrayList<>();
        for (Class<?> token : classes) {
            files.add(root.resolve(getImplName(token) + ".java").toString());
        }
        compileFiles(root, files);
    }

    /**
     * Compile all {@code files}. Using system java compiler.
     *
     * @param root  path for generate correct class-path.
     * @param files {@link List} of files, which must be compiled.
     * @throws ImplerException if can't find system java compiler or exit code from run compiler isn't 0.
     */
    private void compileFiles(Path root, List<String> files) throws ImplerException {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            throw new ImplerException("ERROR: can't find system java compiler. ");
        }
        String var10000 = String.valueOf(root);
        String classpath = var10000 + File.pathSeparator + getClassPath();
        String[] args = Stream.concat(files.stream(), Stream.of("-cp", classpath, "-encoding", "UTF-8")).toArray(String[]::new);
        int exitCode = compiler.run(null, null, null, args);
        if (exitCode != 0) {
            throw new ImplerException("ERROR: run of JavaCompiler get not 0 exit code.");
        }
    }

    /**
     * Get class-path.
     *
     * @return {@link String} with generating class-path.
     */
    private String getClassPath() {
        try {
            return Path.of(Impler.class.getProtectionDomain().getCodeSource().getLocation().toURI()).toString();
        } catch (URISyntaxException var1) {
            throw new AssertionError(var1);
        }
    }

    /**
     * Generate suffix "Impl" for {@code clazz}.
     * To {@code clazz} add suffix "Impl" and replace all '.' to File.separator.
     *
     * @param clazz to get Impl name.
     * @return {@link String} of Impl name.
     */
    private String getImplName(Class<?> clazz) {
        return (clazz.getPackageName() + "." + clazz.getSimpleName() + "Impl").replace(".", File.separator);
    }
}
