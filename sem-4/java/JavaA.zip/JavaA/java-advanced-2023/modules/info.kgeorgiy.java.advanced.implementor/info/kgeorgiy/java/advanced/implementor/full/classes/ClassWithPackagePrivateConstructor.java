package info.kgeorgiy.java.advanced.implementor.full.classes;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public class ClassWithPackagePrivateConstructor {
    ClassWithPackagePrivateConstructor(final int ignore) {
    }
}
