package info.kgeorgiy.java.advanced.student;

/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
public enum GroupName {
    M3232, M3233, M3234, M3235, M3236, M3237, M3238, M3239
}
